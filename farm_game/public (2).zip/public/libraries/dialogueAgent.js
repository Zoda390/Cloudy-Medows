/*
@authors: Patrick
@brief: Turns UI on
*/

class dialogueAgent {

};