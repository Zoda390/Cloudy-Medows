/*
@authors: Whole
@brief: Outputs to canvas
*/

//main stuff starts here

var cloudCount = 8;
var clouds = [];
var tileSize = 32;
var canvasWidth = 23 * tileSize;
var canvasHeight = 19 * tileSize;
var player;
var levels = [];
var currentLevel_y = 1;
var currentLevel_x = 1;
var lastMili = 0;
var maxHunger = 6;
var time = 0;
var timephase = 0;
var lastTimeMili = 0;
var lastHungerMili = 0;
var days = 0;
var title_screen = true;
var all_tiles = [];
var all_items = [];
var Dialouge_JSON = 0;
var paused = false;
var musicSlider = 0;
var fxSlider = 0;
var mouse_item = 0;
var localData = localDataStorage( 'passphrase.life' )
var musicplayer = {};


var startButton;
var optionsButton;
var creditsButton;



function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}



function start(){
    startButton.hide();
    optionsButton.hide();
    creditsButton.hide();
    title_screen = false;
    paused = false;
}
function flipPaused(){
    paused = !paused;
    creditsOn = false;
}

function showOptions(){
    push()
    stroke(149, 108, 65);
    strokeWeight(5);
    fill(187, 132, 75);
    rectMode(CENTER);
    rect(((4*canvasWidth)/5)-10, canvasHeight/2, 300, canvasHeight);
    fill(255);
    stroke(0);
    strokeWeight(2);
    textFont(player_2);
    textAlign(CENTER, CENTER);
    textSize(30);
    text('Options', ((4*canvasWidth)/5)-10, 30);
    musicSlider.show();
    fxSlider.show();
    musicSlider.position(((4*canvasWidth)/5)-30, (canvasHeight/6)-25);
    fxSlider.position(((4*canvasWidth)/5)-30, (canvasHeight/6)+15);

    image(music_note_img, ((4*canvasWidth)/5)-80, (canvasHeight/6)-50);
    image(fx_img, ((4*canvasWidth)/5)-80, (canvasHeight/6)-10);
    pop()
}

function showPaused(){
    push()
    stroke(149, 108, 65);
    strokeWeight(5);
    fill(187, 132, 75);
    rectMode(CENTER);
    rect(canvasWidth/2, (canvasHeight/2)-30, 400, 400);
    fill(255);
    stroke(0);
    strokeWeight(2);
    textFont(player_2);
    textAlign(CENTER, CENTER);
    textSize(30);
    text('Paused', canvasWidth/2, (canvasHeight/5)-20);
    musicSlider.show();
    fxSlider.show();
    musicSlider.position((canvasWidth/2)-10, (canvasHeight/5)+25);
    fxSlider.position((canvasWidth/2)-10, (canvasHeight/5)+65);

    image(music_note_img, (canvasWidth/2)-65, (canvasHeight/5));
    image(fx_img, (canvasWidth/2)-65, (canvasHeight/5)+40);
    pop()
}

var creditsOn = false;
function flipCredits(){
    creditsOn = !creditsOn;
    paused = false;
}
function showCredits(){
    push()
    stroke(149, 108, 65);
    strokeWeight(5);
    fill(187, 132, 75);
    rectMode(CENTER);
    rect(canvasWidth/2 + 120, 150/2, 490, 150 );
    fill(255);
    stroke(0);
    strokeWeight(2);
    textFont(player_2);
    textAlign(CENTER, CENTER);
    text('Credits', canvasWidth/2 + 120, 20);
    text('Christian Rodriguez - Lead programmer \n David Kozdra - Code Art and sound \n Patrick Mayer - UI programming \n Christian “Sealand” Rodriguez - Music', (canvasWidth/2)+120, 80);
    pop()
}


var current_reply = 0;

function draw() {
    musicplayer.update()

    takeInput();
    if (title_screen) {
        background(135, 206, 235);
        push()
        for (let i = 0; i < clouds.length; i++) {
            clouds[i].update(clouds[i].vel)
            clouds[i].render()
        }
        imageMode(CENTER);
        image(title_screen_img, canvasWidth / 2, (canvasHeight / 2) - 40);
        
        textFont(player_2);
        fill('black');
        textAlign(CENTER, CENTER);
        textSize(13);
        
        startButton.show();
        
        pop();

        if(paused){
            showOptions();
        }
        else{
            musicSlider.hide();
            fxSlider.hide();
        }
        if(creditsOn){
            showCredits();
        }
    }
    else {

        startButton.hide();
        optionsButton.hide();
        creditsButton.hide();
        background(135, 206, 235);
        image(background_img, 0, 0);
        levels[currentLevel_y][currentLevel_x].fore_render();
        levels[currentLevel_y][currentLevel_x].render();
        if (!paused){
            for (let y = 0; y < levels.length; y++) {
                for (let x = 0; x < levels[y].length; x++) {
                    if (levels[y][x] != 0) {
                        levels[y][x].update(x, y);
                    }
                }
            }
        }
        player.render();
        if(!player.dead){
            background(0, 0, 0, time);
            render_ui();
        }
        
        if (!paused){

            if (millis() - lastTimeMili > 300) { //300 for 2 min 1 day, 150 for 1 min 1 day
                if (timephase == 0) {
                    if (player.touching.name == 'bed') {
                        time += 5;
                    }
                    else {
                        time += 1;
                    }
                }
                if (timephase == 1) {
                    if (player.touching.name == 'bed') {
                        time -= 5;
                    }
                    else {
                        time -= 1;
                    }
                }
                if (time >= 200) {
                    timephase = 1;
                    days += 1;
                    newDayChime.play();
                }
                if (time <= 0) {
                    timephase = 0;
                    for (let y = 0; y < levels.length; y++) {
                        for (let x = 0; x < levels[y].length; x++) {
                            if (levels[y][x] != 0) {
                                levels[y][x].daily_update();
                            }
                        }
                    }
                }
                lastTimeMili = millis();
            }
        }
    }
}


function addItem(to, item_obj_num, amount) {
    for (let i = 0; i < to.inv.length; i++) {
        if (to.inv[i] != 0) { // stack items
            if (to.inv[i].name == all_items[item_obj_num].name) {
                to.inv[i].amount += amount;
                return;
            }
        }
    }
    if (to.inv[to.hand] == 0) { // air
        to.inv[to.hand] = new_item_from_num(item_obj_num, amount);
        return;
    }

    for (let i = 0; i < 8; i++) {
        if (to.inv[i] == 0) { // find space
            to.inv[i] = new_item_from_num(item_obj_num, amount);
            return;
        }
    }
}

function checkForSpace(to, item_obj_num){
    var check = false;
    for (let i = 0; i < to.inv.length; i++) {
        if (to.inv[i] != 0) { // stack items
            if (to.inv[i].name == all_items[item_obj_num].name) {
                check = true;
                return check;
            }
        }
    }
    if (to.inv[to.hand] == 0) { // air in hand
        check = true;
        return check;
    }

    for (let i = 0; i < 8; i++) {
        if (to.inv[i] == 0) { // find space
            check = true;
            return check;
        }
    }
    return check;
}

function item_name_to_num(item_name) {
    for (let i = 0; i < all_items.length; i++) {
        if (item_name == all_items[i].name) {
            return i;
        }
    }
}

function tile_name_to_num(tile_name) {
    for (let i = 0; i < all_tiles.length; i++) {
        if (tile_name == all_tiles[i].name) {
            return i;
        }
    }
}



//keys
var move_right_button = 68;//d
var move_left_button = 65; //a
var move_up_button = 87;   //w
var move_down_button = 83; //s
var interact_button = 69;  //e
var eat_button = 81;       //q
var pause_button = 27;     //esc
function takeInput() {
            
    if (title_screen) {
        if (keyIsDown(interact_button)) {
            title_screen = false;
        }
    }
    else if(paused){
        if(keyIsDown(pause_button)){
            if (millis() - lastMili > 200) {
                paused = false;
                lastMili = millis();
            }
        }
    }
    else if(player.talking != 0){
        if(keyIsDown(pause_button)){
            if (millis() - lastMili > 200) {
                paused = true;
                lastMili = millis();
            }
        }
        if (keyIsDown(eat_button)) {
            if (millis() - lastMili > 200) {
                if(player.talking.class == 'NPC'){
                    player.talking.move_bool = true;
                    player.talking.current_dialouge = 0;
                    for(let i = 0; i < player.talking.dialouges.length; i++){
                        player.talking.dialouges[i].done = false;
                        player.talking.dialouges[i].phrase = [];
                        if(player.talking.dialouges[i].new_phrase != -1){
                            player.talking.dialouges[i].phrase2 = player.talking.dialouges[i].new_phrase;
                            player.talking.dialouges[i].new_phrase = -1;
                        }
                        if(player.talking.dialouges[i].new_replies != -1){
                            for(let j = 0; j < player.talking.dialouges[i].new_replies.length; j++){
                                player.talking.dialouges[i].replies[j] = player.talking.dialouges[i].new_replies[j];
                            }
                            player.talking.dialouges[i].new_replies = -1;
                        }
                    }
                }
                else if(player.talking.class == 'Chest'){
                    if(mouse_item != 0){
                        if(checkForSpace(player, item_name_to_num(mouse_item.name))){
                            addItem(player, item_name_to_num(mouse_item.name), mouse_item.amount);
                            mouse_item = 0;
                        }
                        else{
                            let dropped = false;
                            for (let i = 0; i < player.talking.inv.length; i++) {
                                for(let j = 0; j < player.talking.inv[i].length; j++){
                                    if (player.talking.inv[i][j] != 0) { // stack items
                                        if (player.talking.inv[i][j].name == mouse_item.name) {
                                            player.talking.inv[i][j].amount += mouse_item.amount;
                                            dropped = true;
                                        }
                                    }
                                }
                            }
                            for (let i = 0; i < player.talking.inv.length; i++) {
                                for(let j = 0; j < player.talking.inv[i].length; j++){
                                    if (player.inv[i] == 0) { // empty space
                                        player.talking.inv[i][j] = mouse_item;
                                        dropped = true;
                                    }
                                }
                            }
                            if(!dropped){
                                return;
                            }
                        }
                    }
                }
                else if (player.talking.class == 'Robot'){
                    player.talking.fuel_timer = player.talking.max_fuel_timer;
                    player.talking.move_bool = true;
                }
                player.oldlooking_name = player.talking.name;
                player.talking = 0;
                current_reply = 0;
                lastMili = millis();
                player.lasteatMili = millis();
            }
        }
        if (keyIsDown(move_up_button)){
            if ((millis() - lastMili > 200) && player.talking.class != 'Chest') {
                current_reply -= 1;
                if (current_reply < 0){
                    current_reply = 0;
                }
                lastMili = millis();
            }
        }
        if (keyIsDown(move_down_button)){
            if (millis() - lastMili > 200) {
                current_reply += 1;
                if (player.talking.class == 'NPC'){
                    if (current_reply > player.talking.dialouges[player.talking.current_dialouge].replies.length-1){
                        current_reply = player.talking.dialouges[player.talking.current_dialouge].replies.length-1;
                    }
                }
                else if (player.talking.class == 'Shop'){
                    if (current_reply > player.talking.inv.length-1){
                        current_reply = player.talking.inv.length-1;
                    }
                }
                lastMili = millis();
            }
        }
        if (keyIsDown(interact_button)){
            if (millis() - lastMili > 200) {
                if (player.talking.class == 'NPC'){
                    if(player.talking.dialouges[player.talking.current_dialouge].replies[current_reply].dialouge_num == -1){
                        player.talking.move_bool = true;
                        player.talking.current_dialouge = 0;
                        for(let i = 0; i < player.talking.dialouges.length; i++){
                            player.talking.dialouges[i].done = false;
                            player.talking.dialouges[i].phrase = [];
                            if(player.talking.dialouges[i].new_phrase != -1){
                                player.talking.dialouges[i].phrase2 = player.talking.dialouges[i].new_phrase;
                                player.talking.dialouges[i].new_phrase = -1;
                            }
                            if(player.talking.dialouges[i].new_replies != -1){
                                for(let j = 0; j < player.talking.dialouges[i].new_replies.length; j++){
                                    player.talking.dialouges[i].replies[j] = player.talking.dialouges[i].new_replies[j];
                                }
                                player.talking.dialouges[i].new_replies = -1;
                            }
                        }
                        player.oldlooking_name = player.talking.name;
                        player.talking = 0;
                        current_reply = 0;
                        player.lastinteractMili = millis();
                    }
                    else{
                        player.talking.current_dialouge = player.talking.dialouges[player.talking.current_dialouge].replies[current_reply].dialouge_num;
                    }
                }
                else if (player.talking.class == 'Shop'){
                    if(player.talking.inv[current_reply].amount >= 1){
                        if(player.coins >= player.talking.inv[current_reply].price){    //check if you have the money
                            addItem(player, item_name_to_num(player.talking.inv[current_reply].name), 1);
                            player.coins -= player.talking.inv[current_reply].price; //reduce money
                            player.talking.inv[current_reply].amount -= 1; //shop.inv -1 amount
                        }
                    }
                }
                lastMili = millis();
            }
            
        }
        if (keyIsDown(80)) { //p
            if (millis() - lastMili > 100) {
                console.log(player);
                console.log(player.touching);
                console.log(player.looking(currentLevel_x, currentLevel_y));
                console.log(all_tiles)
                lastMili = millis();
                player.hunger = maxHunger;
            }
        }
    }
    else {
        if(keyIsDown(pause_button)){
            if (millis() - lastMili > 200) {
                paused = true;
                lastMili = millis();
            }
        }
        //basic movement  
        player.move();
        if (keyIsDown(eat_button)) {
            player.eat();
        }
        if (keyIsDown(interact_button)) {
        
            player.interactCall();
        }
        /*
        if(keyIsDown(48)){
          player.hand = 9;
        }
        */
        //mc style hotbar
        if (keyIsDown(49)) {
            player.hand = 0;
        }
        if (keyIsDown(50)) {
            player.hand = 1;
        }
        if (keyIsDown(51)) {
            player.hand = 2;
        }
        if (keyIsDown(52)) {
            player.hand = 3;
        }
        if (keyIsDown(53)) {
            player.hand = 4;
        }
        if (keyIsDown(54)) {
            player.hand = 5;
        }
        if (keyIsDown(55)) {
            player.hand = 6;
        }
        if (keyIsDown(56)) {
            player.hand = 7;
        }

        /*
        if(keyIsDown(57)){
          player.hand = 8;
        }
        */
        if (keyIsDown(80)) { //p
            if (millis() - lastMili > 100) {
                console.log(player);
                console.log(player.touching);
                console.log(player.looking(currentLevel_x, currentLevel_y));
                lastMili = millis();
                player.hunger = maxHunger;
            }
        }
    }
}

//Christian's function to make UI more readible, positioning + math stuff
function render_ui() {
    //calendar
    push();
    image(calendar_img, canvasWidth - 70, 6);
    textFont(player_2);
    fill(255, 0, 0);
    textAlign(CENTER, CENTER);
    textSize(13);
    text('days', canvasWidth - 39, 30);
    textSize(15);
    text(days, canvasWidth - 40, 50);
    pop();

    if(levels[currentLevel_y][currentLevel_x].level_name_popup){
        levels[currentLevel_y][currentLevel_x].name_render();
    }

    if (player.talking != undefined && player.talking != 0 && player.talking.class != 'Chest' && player.talking.class != 'Robot') {
        if (player.talking.class == 'NPC' ){
            player.talking.move_bool = false;
            player.talking.dialouge_render();
        }
        else if (player.talking.class == 'Shop'){
            player.talking.shop_render();
        }
        for (let i = 0; i < maxHunger; i++) {
            image(hunger_e, (canvasWidth / 20) + (30 * i), (canvasHeight - 185));
        }
        for (let i = 0; i < player.hunger; i++) {
            image(hunger_f, (canvasWidth / 20) + (30 * i), (canvasHeight - 185));
        }
        textFont(player_2);
        textSize(32.5);
        fill(0);
        textAlign(LEFT, TOP);
        image(coin_img, canvasWidth - 140, (canvasHeight - 185));
        text(player.coins, canvasWidth - 110, (canvasHeight - 182.5));
    }
    else{
        if(player.talking != undefined && player.talking != 0){
            if (player.talking.class == 'Chest'){
                player.talking.chest_render();
            }
            else if(player.talking.class == 'Robot'){
                player.talking.move_bool = false;
                player.talking.render_pc();
            }
        }
        image(inv_img, (canvasWidth / 2) - (512 / 2), canvasHeight - 64);
        image(inv_hand_img, (canvasWidth / 2) - (512 / 2) + (64 * player.hand), canvasHeight - 64);
        
        for (let i = 0; i < 8; i++) {
            if (player.inv[i] == undefined) {
                player.inv[i] = 0;
            }
            if (player.inv[i] != 0) {
                player.inv[i].render(112 + (i * 64), canvasHeight - 64);
                if (i == player.hand) {
                    push();
                    fill(255)
                    textSize(13);
                    textAlign(CENTER, CENTER);
                    text(player.inv[i].name, (9 * canvasWidth / 16), (canvasHeight - 80));
                    pop()
                }
            }
        }
        for (let i = 0; i < maxHunger; i++) {
            image(hunger_e, (canvasWidth / 2) - (512 / 2) + (30 * i), (canvasHeight - 100));
        }
        for (let i = 0; i < player.hunger; i++) {
            image(hunger_f, (canvasWidth / 2) - (512 / 2) + (30 * i), (canvasHeight - 100));
        }
        textFont(player_2);
        textSize(32.5);
        fill(0);
        textAlign(LEFT, TOP);
        image(coin_img, (canvasWidth / 2) + (512 / 2) - 100, (canvasHeight - 95));
        text(player.coins, (canvasWidth / 2) + (512 / 2) - 64, (canvasHeight - 92.5));
        if(mouse_item != 0){
            mouse_item.render(mouseX-32, mouseY-32);
        }
        if (player.looking(currentLevel_x, currentLevel_y) != undefined && player.looking(currentLevel_x, currentLevel_y).name == "cart_s") {
            push()
            stroke(0)
            stroke(149, 108, 65);
            strokeWeight(5);
            fill(187, 132, 75);
            rectMode(CENTER)
            rect(player.looking(currentLevel_x, currentLevel_y).pos.x + (tileSize / 2), player.looking(currentLevel_x, currentLevel_y).pos.y - tileSize, 90, 70);
            textAlign(CENTER, CENTER);
            textSize(15);
            fill(255);
            stroke(0);
            strokeWeight(4);
            text('Sell', player.looking(currentLevel_x, currentLevel_y).pos.x + (tileSize / 2), player.looking(currentLevel_x, currentLevel_y).pos.y - (tileSize * 1.5), 90, 70);
            image(coin_img, player.looking(currentLevel_x, currentLevel_y).pos.x - (tileSize / 2) - 5, player.looking(currentLevel_x, currentLevel_y).pos.y - (tileSize * 1));
            if (player.inv[player.hand].price == 0 || player.inv[player.hand] == 0) {
                fill(255, 0, 0);
                text("No", player.looking(currentLevel_x, currentLevel_y).pos.x + (tileSize), player.looking(currentLevel_x, currentLevel_y).pos.y - (tileSize / 2));
            }
            if (player.inv[player.hand].price > 0) {
                fill(255);
                text(player.inv[player.hand].price, player.looking(currentLevel_x, currentLevel_y).pos.x + (tileSize), player.looking(currentLevel_x, currentLevel_y).pos.y - (tileSize / 2));
            }
            pop()
    
        }
    }
    if(paused){
        showPaused();
    }
    else{
        musicSlider.hide();
        fxSlider.hide();
    }
}


function new_tile_from_num(num, x, y) {
    if (num-1 <= all_tiles.length) {
        if (all_tiles[num - 1].class == 'Tile') {
            return new Tile(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].border, all_tiles[num - 1].collide, all_tiles[num - 1].age);
        }
        else if (all_tiles[num - 1].class == 'Shop') {
            return new Shop(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv);
        }
        else if (all_tiles[num - 1].class == 'Plant') {
            return new Plant(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].border, all_tiles[num - 1].collide, all_tiles[num - 1].eat_num, all_tiles[num - 1].waterneed, all_tiles[num - 1].growthTime);
        }
        else if (all_tiles[num - 1].class == 'Entity') {
            return new Entity(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].age, all_tiles[num - 1].inv, all_tiles[num - 1].hand, all_tiles[num - 1].under_tile_num);
        }
        else if (all_tiles[num - 1].class == 'FreeMoveEntity') {
            return new FreeMoveEntity(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].border, all_tiles[num - 1].collide, all_tiles[num - 1].age);
        }
        else if (all_tiles[num - 1].class == 'MovableEntity') {
            return new MoveableEntity(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv, all_tiles[num - 1].hand, all_tiles[num - 1].facing, all_tiles[num - 1].under_tile_num, all_tiles[num - 1].moving_timer);
        }
        else if (all_tiles[num - 1].class == 'GridMoveEntity') {
            return new GridMoveEntity(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv, all_tiles[num - 1].hand, all_tiles[num - 1].facing, all_tiles[num - 1].under_tile_num, all_tiles[num - 1].instructions, all_tiles[num - 1].moving_timer);
        }
        else if (all_tiles[num - 1].class == 'NPC') {
            return new NPC(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv, all_tiles[num - 1].hand, all_tiles[num - 1].facing, all_tiles[num - 1].under_tile_num, all_tiles[num - 1].instructions, all_tiles[num - 1].moving_timer);
        }
        else if (all_tiles[num - 1].class == 'Chest'){
            return new Chest(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv, all_tiles[num - 1].under_tile_num);
        }
        else if (all_tiles[num - 1].class == 'Robot'){
            return new Robot(all_tiles[num - 1].name, all_tiles[num - 1].png, x, y, all_tiles[num - 1].inv, all_tiles[num - 1].under_tile_num, all_tiles[num - 1].instructions, all_tiles[num - 1].moving_timer);
        }
    }
    else {
        console.log('tile created from ' + num + ' doesnt exist');
    }
}

function new_item_from_num(num, amount) {
    if (num <= all_items.length) {
        if (all_items[num].class == 'Item') {
            return new Item(all_items[num].name, amount, all_items[num].png, all_items[num].price);
        }
        else if (all_items[num].class == 'Tool') {
            return new Tool(all_items[num].name, amount, all_items[num].png);
        }
        else if (all_items[num].class == 'Eat') {
            return new Eat(all_items[num].name, amount, all_items[num].png, all_items[num].price, all_items[num].hunger, all_items[num].hunger_timer, all_items[num].seed_num);
        }
        else if (all_items[num].class == 'Seed') {
            return new Seed(all_items[num].name, amount, all_items[num].png, all_items[num].plant_num);
        }
        else if (all_items[num].class == 'Placeable') {
            return new Placeable(all_items[num].name, amount, all_items[num].png, all_items[num].price, all_items[num].tile_num, all_items[num].tile_need_num);
        }
        else if(all_items[num].class == 'Command'){
            return new Command(all_items[num].name, amount, all_items[num].png, all_items[num].command);
        }
    }
    else {
        console.error('item created from ' + num + ' doesnt exist');
    }
}

function mouseReleased() {
    if(!title_screen){
        if(mouseY >= canvasHeight - 64 && mouseY <= canvasHeight){
            if(mouseX >= 113 && mouseX <= 622){
                let currentX = min(player.inv.length-1, round((mouseX-113-32)/64))
                if(mouse_item == 0 || player.inv[currentX] == 0){
                    let temp = mouse_item;
                    mouse_item = player.inv[currentX]
                    player.inv[currentX] = temp;
                }
                else if(player.inv[currentX].name == mouse_item.name){
                    player.inv[currentX].amount += mouse_item.amount;
                    mouse_item = 0;
                }
                else{
                    let temp = mouse_item;
                    mouse_item = player.inv[currentX]
                    player.inv[currentX] = temp;
                }
            }
        }
        if(player.looking(currentLevel_x, currentLevel_y) != undefined && player.talking != 0 && player.looking(currentLevel_x, currentLevel_y).class == 'Chest'){
            if(mouseY >= 189 && mouseY <= 457){
                if(mouseX >= 184 && mouseX <= 552){
                    let currentX = min(player.talking.inv[0].length-1, round((mouseX-229)/90))
                    let currentY = min(player.talking.inv.length-1, round((mouseY-234)/90))
                    if(mouse_item == 0 || player.talking.inv[currentY][currentX] == 0){
                        let temp = mouse_item;
                        mouse_item = player.talking.inv[currentY][currentX]
                        player.talking.inv[currentY][currentX] = temp;
                    }
                    else if(player.talking.inv[currentY][currentX].name == mouse_item.name){
                        player.talking.inv[currentY][currentX].amount += mouse_item.amount;
                        mouse_item = 0;
                    }
                    else{
                        let temp = mouse_item;
                        mouse_item = player.talking.inv[currentY][currentX]
                        player.talking.inv[currentY][currentX] = temp;
                    }
                }
            }
        }
        if(player.looking(currentLevel_x, currentLevel_y) != undefined && player.talking != 0 && player.looking(currentLevel_x, currentLevel_y).class == 'Robot'){
            if(mouseY >= 78 && mouseY <= (ceil(player.talking.instructions.length/6)*86)+78){
                if(mouseX >= 152 && mouseX <= 682){
                    let currentX = (min(player.talking.instructions.length/6, round((mouseY - 78-(86/2))/86))*6) + min(5, round((mouseX - 152-45)/90))
                    if(mouse_item == 0){
                        mouse_item = player.talking.instructions[currentX];
                        player.talking.instructions[currentX] = 0;
                    }
                    else if(player.talking.instructions[currentX] == 0){
                        player.talking.instructions[currentX] = new_item_from_num(item_name_to_num(mouse_item.name), 1);
                        mouse_item.amount -= 1;
                        if(mouse_item.amount == 0){
                        mouse_item = 0;
                        }
                    }
                    else if (player.talking.instructions[currentX].name == mouse_item.name){
                        mouse_item.amount += 1;
                        player.talking.instructions[currentX] = 0;
                    }
                    else{
                        let temp = mouse_item;
                        mouse_item = player.talking.instructions[currentX];
                        player.talking.instructions[currentX] = temp;
                    }
                }
            }
            if(mouseY >= 435 && mouseY <= 500){
                if(mouseX >= 70 && mouseX <= 678){
                    let currentX = min(player.talking.inv.length-1, round((mouseX-70-45)/90))
                    if(mouse_item == 0 || player.talking.inv[currentX] == 0){
                        let temp = mouse_item;
                        mouse_item = player.talking.inv[currentX]
                        player.talking.inv[currentX] = temp;
                    }
                    else if(player.talking.inv[currentX].name == mouse_item.name){
                        player.talking.inv[currentX].amount += mouse_item.amount;
                        mouse_item = 0;
                    }
                    else{
                        let temp = mouse_item;
                        mouse_item = player.talking.inv[currentX]
                        player.talking.inv[currentX] = temp;
                    }
                }
            }
        }
    }
  }