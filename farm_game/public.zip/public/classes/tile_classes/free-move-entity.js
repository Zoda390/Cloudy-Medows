class FreeMoveEntity extends Entity{

    constructor(){
        super()
    }
}