/*
@authors: Patrick
@brief: Turns UI on
*/

//obj "talking to"

class dialogueHandler {

};